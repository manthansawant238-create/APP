
import { GoogleGenAI, Type } from "@google/genai";
import { ScriptFramework, Tone, ChannelProfile, ScriptSection } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateResearchAndHooks(topic: string, niche: string) {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze this YouTube topic: "${topic}" in the "${niche}" niche. 
    1. Research key facts and trends.
    2. Generate 3 unique "Scroll-Stopping" hook variations for the first 15 seconds. 
    Focus on curiosity gaps and emotional triggers.`,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          research: { type: Type.STRING, description: "A summary of research facts." },
          hooks: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING },
            description: "Three distinct viral-optimized hook scripts."
          }
        },
        required: ["research", "hooks"]
      }
    }
  });

  return JSON.parse(response.text);
}

export async function generateFullScript(
  topic: string, 
  framework: ScriptFramework, 
  tone: Tone, 
  profile: ChannelProfile,
  research: string,
  selectedHook: string
) {
  const systemPrompt = `You are a world-class YouTube scriptwriter for a ${profile.niche} channel. 
  Your goal is maximum viewer retention. Use "Open Loops", "Pattern Interrupts", and "Conversational Narration". 
  Avoid AI clichés like "In today's video" or "Let's dive in". 
  Write for the specific audience: ${profile.targetAudience}.`;

  const prompt = `Write a full ${framework} script for the topic: "${topic}".
  Tone: ${tone}. 
  Research to incorporate: ${research}
  Selected Hook to start with: ${selectedHook}
  
  Structure the output into the following sections:
  1. Introduction & Hook (Already provided, polish it)
  2. The Stakes/Problem (Why this matters)
  3. Core Body (The detailed content, structured with loops)
  4. Conclusion & Retention-focused CTA.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      systemInstruction: systemPrompt,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            label: { type: Type.STRING },
            content: { type: Type.STRING }
          },
          required: ["label", "content"]
        }
      }
    }
  });

  return JSON.parse(response.text);
}

export async function regenerateSection(
  currentContent: string, 
  instruction: string,
  tone: Tone
) {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Rewrite the following script section according to these instructions: "${instruction}". 
    Maintain a ${tone} tone. Keep the output focused on the section content only.
    
    Current Section:
    ${currentContent}`,
  });

  return response.text;
}
