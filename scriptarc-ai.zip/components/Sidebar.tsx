
import React from 'react';
import { ICONS } from '../constants';

interface SidebarProps {
  currentView: string;
  onViewChange: (view: any) => void;
  credits: number;
  tier: string;
}

export default function Sidebar({ currentView, onViewChange, credits, tier }: SidebarProps) {
  const NavItem = ({ view, label, icon: Icon }: any) => (
    <button
      onClick={() => onViewChange(view)}
      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 ${
        currentView === view 
          ? 'bg-[#FF6A3D] text-white shadow-lg shadow-[#FF6A3D]/20' 
          : 'text-[#9AA3B2] hover:bg-[#1F262F] hover:text-[#EAEAF0]'
      }`}
    >
      <Icon />
      <span className="font-medium">{label}</span>
    </button>
  );

  return (
    <aside className="w-64 bg-[#151A22] border-r border-[#1F262F] flex flex-col h-screen sticky top-0 shadow-xl">
      <div className="p-6">
        <div className="flex items-center space-x-2 mb-10">
          <div className="w-8 h-8 bg-[#FF6A3D] rounded-lg flex items-center justify-center shadow-lg shadow-[#FF6A3D]/30">
            <span className="text-white font-bold text-xl">S</span>
          </div>
          <span className="text-xl font-bold tracking-tight text-[#EAEAF0]">ScriptArc</span>
        </div>

        <nav className="space-y-3">
          <NavItem view="dashboard" label="Dashboard" icon={ICONS.Dashboard} />
          <NavItem view="channels" label="Channel Profiles" icon={ICONS.Channel} />
          <NavItem view="pricing" label="Upgrade Plans" icon={ICONS.Settings} />
        </nav>
      </div>

      <div className="mt-auto p-6 space-y-6">
        <div className="bg-[#1F262F] p-4 rounded-xl border border-[#2D3643]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#9AA3B2]">Credits</span>
            <span className="text-xs font-bold text-[#FF6A3D]">{tier === 'agency' ? 'Unlimited' : `${credits} left`}</span>
          </div>
          <div className="w-full bg-[#0E1116] rounded-full h-1.5">
            <div className="bg-[#FF6A3D] h-1.5 rounded-full transition-all duration-500" style={{ width: tier === 'agency' ? '100%' : `${(credits/10)*100}%` }}></div>
          </div>
          <button 
            onClick={() => onViewChange('pricing')}
            className="w-full mt-3 text-[10px] uppercase tracking-widest font-bold text-[#FF6A3D] hover:text-white transition-colors text-left"
          >
            Upgrade Plan &rarr;
          </button>
        </div>
        
        <div className="flex items-center space-x-3 px-2 py-1">
          <div className="w-9 h-9 rounded-full bg-[#2D3643] border border-[#FF6A3D]/20 flex items-center justify-center text-[#FF6A3D] font-bold">
            CU
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-[#EAEAF0] truncate">Creator User</p>
            <p className="text-xs text-[#C77DFF] font-medium capitalize">{tier} Plan</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
