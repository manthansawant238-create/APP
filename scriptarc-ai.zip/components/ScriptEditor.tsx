
import React, { useState } from 'react';
import { YouTubeScript, ScriptSection } from '../types';
import { regenerateSection } from '../services/gemini';

interface ScriptEditorProps {
  script: YouTubeScript;
  tier: string;
  onUpdate: (updated: YouTubeScript) => void;
  onBack: () => void;
}

export default function ScriptEditor({ script, tier, onUpdate, onBack }: ScriptEditorProps) {
  const [activeSectionId, setActiveSectionId] = useState(script.sections[0]?.id);
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [instruction, setInstruction] = useState('');

  const activeSection = script.sections.find(s => s.id === activeSectionId);

  const handleUpdateContent = (content: string) => {
    const updatedSections = script.sections.map(s => 
      s.id === activeSectionId ? { ...s, content } : s
    );
    onUpdate({ ...script, sections: updatedSections });
  };

  const handleRegenerate = async () => {
    if (tier === 'free') {
      alert('Section regeneration is a PRO feature. Please upgrade your plan.');
      return;
    }
    if (!activeSection || !instruction.trim()) return;
    setIsRegenerating(true);
    try {
      const newContent = await regenerateSection(activeSection.content, instruction, script.tone);
      handleUpdateContent(newContent);
      setInstruction('');
    } catch (e) {
      console.error(e);
    } finally {
      setIsRegenerating(false);
    }
  };

  const copyToClipboard = () => {
    const fullText = script.sections.map(s => `[${s.label}]\n${s.content}`).join('\n\n');
    navigator.clipboard.writeText(fullText);
    alert('Full script copied to clipboard!');
  };

  return (
    <div className="flex flex-col h-[calc(100vh-120px)] animate-in fade-in duration-500">
      <header className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <button onClick={onBack} className="p-2 hover:bg-[#1F262F] rounded-lg text-[#9AA3B2] transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
          </button>
          <div>
            <h1 className="text-2xl font-bold text-[#EAEAF0] line-clamp-1">{script.title}</h1>
            <div className="flex items-center space-x-2 text-xs text-[#9AA3B2] mt-0.5">
              <span className="font-bold text-[#FF6A3D] uppercase tracking-widest">{script.framework}</span>
              <span className="opacity-20">•</span>
              <span className="font-medium">Tone: {script.tone}</span>
            </div>
          </div>
        </div>
        <button 
          onClick={copyToClipboard}
          className="bg-[#1F262F] border border-[#2D3643] hover:border-[#FF6A3D]/40 text-[#EAEAF0] px-5 py-2.5 rounded-xl font-bold transition-all shadow-sm flex items-center space-x-2 active:scale-95"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-[#FF6A3D]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
          </svg>
          <span>Copy Full Script</span>
        </button>
      </header>

      <div className="flex-1 flex space-x-8 min-h-0">
        {/* Section Navigation */}
        <div className="w-64 flex flex-col space-y-3 overflow-y-auto pr-1">
          {script.sections.map((section, idx) => (
            <button
              key={section.id}
              onClick={() => setActiveSectionId(section.id)}
              className={`text-left p-4 rounded-xl transition-all border-2 group ${
                activeSectionId === section.id 
                ? 'bg-[#151A22] border-[#FF6A3D] shadow-lg shadow-[#FF6A3D]/5' 
                : 'bg-transparent border-transparent hover:bg-[#1F262F] text-[#9AA3B2] hover:text-[#EAEAF0]'
              }`}
            >
              <div className={`text-[10px] font-bold uppercase mb-1 tracking-widest transition-colors ${activeSectionId === section.id ? 'text-[#FF6A3D]' : 'text-[#2D3643]'}`}>Section {idx + 1}</div>
              <div className="text-sm font-bold truncate">{section.label}</div>
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="flex-1 flex flex-col min-w-0 bg-[#151A22] rounded-3xl border border-[#1F262F] shadow-2xl overflow-hidden">
          {activeSection ? (
            <>
              <div className="px-8 py-4 border-b border-[#1F262F] bg-[#1F262F]/30 flex items-center justify-between">
                <span className="text-sm font-bold text-[#FF6A3D] uppercase tracking-widest">{activeSection.label}</span>
                <span className="text-xs text-[#9AA3B2] font-medium">{activeSection.content.split(' ').length} words</span>
              </div>
              <div className="flex-1 p-8 overflow-y-auto">
                <textarea
                  value={activeSection.content}
                  onChange={(e) => handleUpdateContent(e.target.value)}
                  className="w-full h-full text-lg leading-relaxed text-[#EAEAF0] bg-transparent outline-none resize-none font-medium placeholder-[#9AA3B2]/20"
                  placeholder="Start writing..."
                />
              </div>
              {/* AI Quick Edit Bar */}
              <div className="p-6 bg-[#0E1116] border-t border-[#1F262F]">
                <div className="flex items-center space-x-4 bg-[#151A22] p-2 rounded-2xl border border-[#1F262F] shadow-xl">
                  <div className="relative flex-1 flex items-center">
                    <input 
                      type="text" 
                      value={instruction}
                      onChange={(e) => setInstruction(e.target.value)}
                      placeholder={tier === 'free' ? "Section Regeneration (PRO Only)" : "Ask AI to improve this section (e.g., 'make it punchier')"} 
                      className={`flex-1 px-4 py-2 bg-transparent outline-none text-[#EAEAF0] text-sm placeholder-[#9AA3B2]/40 ${tier === 'free' ? 'cursor-not-allowed opacity-50' : ''}`}
                      disabled={tier === 'free'}
                    />
                    {tier === 'free' && (
                      <div className="absolute right-4 text-[10px] font-black text-[#C77DFF] uppercase tracking-widest">Locked</div>
                    )}
                  </div>
                  <button 
                    onClick={handleRegenerate}
                    disabled={isRegenerating || (tier !== 'free' && !instruction.trim())}
                    className="bg-[#FF6A3D] text-white px-6 py-2 rounded-xl text-sm font-bold hover:bg-[#FF8A66] disabled:opacity-50 transition-all active:scale-95 shadow-lg shadow-[#FF6A3D]/20"
                  >
                    {isRegenerating ? 'Rewriting...' : 'Regenerate'}
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-[#9AA3B2]">
              Select a section to begin editing.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
