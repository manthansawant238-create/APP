
import React, { useState } from 'react';
import { ChannelProfile, ScriptFramework, Tone, YouTubeScript } from '../types';
import { FRAMEWORKS, TONES } from '../constants';
import { generateResearchAndHooks, generateFullScript } from '../services/gemini';

interface GeneratorModalProps {
  profiles: ChannelProfile[];
  tier: 'free' | 'creator' | 'agency';
  onClose: () => void;
  onSubmit: (script: YouTubeScript) => void;
}

export default function GeneratorModal({ profiles, tier, onClose, onSubmit }: GeneratorModalProps) {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Form State
  const [topic, setTopic] = useState('');
  const [selectedProfile, setSelectedProfile] = useState(profiles[0]);
  const [framework, setFramework] = useState(ScriptFramework.Documentary);
  const [tone, setTone] = useState(Tone.Dramatic);
  
  // AI Derived State
  const [research, setResearch] = useState('');
  const [hooks, setHooks] = useState<string[]>([]);
  const [selectedHookIndex, setSelectedHookIndex] = useState(0);

  const isProFramework = (f: string) => {
    return [ScriptFramework.ViralShortLong, ScriptFramework.CaseStudy].includes(f as any);
  };

  const handleNext = async () => {
    if (step === 1) {
      if (!topic.trim()) return setError('Please enter a topic');
      setLoading(true);
      setError(null);
      try {
        const data = await generateResearchAndHooks(topic, selectedProfile.niche);
        setResearch(data.research);
        setHooks(data.hooks);
        setStep(2);
      } catch (e) {
        setError('Failed to research topic. Please try again.');
      } finally {
        setLoading(false);
      }
    } else if (step === 2) {
      setLoading(true);
      setError(null);
      try {
        const sectionsData = await generateFullScript(
          topic, 
          framework, 
          tone, 
          selectedProfile, 
          research, 
          hooks[selectedHookIndex]
        );
        
        const newScript: YouTubeScript = {
          id: Math.random().toString(36).substr(2, 9),
          title: topic,
          topic,
          framework,
          tone,
          createdAt: Date.now(),
          metadata: {
            researchSummary: research,
            hookOptions: hooks
          },
          sections: sectionsData.map((s: any, i: number) => ({
            id: `s-${i}`,
            label: s.label,
            content: s.content,
            status: 'draft'
          }))
        };
        onSubmit(newScript);
      } catch (e) {
        setError('Failed to generate script. Please try again.');
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0E1116]/80 backdrop-blur-sm">
      <div className="bg-[#151A22] w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border border-[#1F262F]">
        <div className="p-8">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h2 className="text-2xl font-bold text-[#EAEAF0]">New Viral Script</h2>
              <div className="flex space-x-2 mt-3">
                {[1, 2].map(s => (
                  <div key={s} className={`h-1.5 w-12 rounded-full transition-colors ${step >= s ? 'bg-[#FF6A3D]' : 'bg-[#1F262F]'}`} />
                ))}
              </div>
            </div>
            <button onClick={onClose} className="text-[#9AA3B2] hover:text-[#EAEAF0] p-2 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-900/20 border border-red-500/20 text-red-400 rounded-xl text-sm font-medium">
              {error}
            </div>
          )}

          {step === 1 && (
            <div className="space-y-6">
              <div>
                <label className="block text-xs font-bold text-[#9AA3B2] uppercase tracking-widest mb-2">Video Topic or Idea</label>
                <textarea 
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="e.g., The untold story of why Nokia failed to adapt..."
                  className="w-full h-32 px-4 py-3 rounded-xl bg-[#0E1116] border border-[#1F262F] text-[#EAEAF0] focus:ring-2 focus:ring-[#FF6A3D] focus:border-transparent outline-none transition-all resize-none placeholder-[#9AA3B2]/30"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#9AA3B2] uppercase tracking-widest mb-2">Channel Profile</label>
                  <select 
                    className="w-full px-4 py-3 rounded-xl bg-[#0E1116] border border-[#1F262F] text-[#EAEAF0] outline-none focus:ring-2 focus:ring-[#FF6A3D]"
                    value={selectedProfile.id}
                    onChange={(e) => setSelectedProfile(profiles.find(p => p.id === e.target.value)!)}
                  >
                    {profiles.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#9AA3B2] uppercase tracking-widest mb-2">Framework</label>
                  <select 
                    className="w-full px-4 py-3 rounded-xl bg-[#0E1116] border border-[#1F262F] text-[#EAEAF0] outline-none focus:ring-2 focus:ring-[#FF6A3D]"
                    value={framework}
                    onChange={(e) => setFramework(e.target.value as ScriptFramework)}
                  >
                    {FRAMEWORKS.map(f => (
                      <option key={f} value={f} disabled={tier === 'free' && isProFramework(f)}>
                        {f} {tier === 'free' && isProFramework(f) ? '(PRO)' : ''}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-xs font-bold text-[#9AA3B2] uppercase tracking-widest">Choose your Hook</label>
                  {tier !== 'free' && (
                    <span className="text-[10px] text-[#C77DFF] font-black uppercase tracking-[0.2em]">Priority Research Active</span>
                  )}
                </div>
                <div className="space-y-3 max-h-60 overflow-y-auto pr-2 custom-scrollbar">
                  {hooks.map((h, i) => (
                    <div 
                      key={i}
                      onClick={() => setSelectedHookIndex(i)}
                      className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                        selectedHookIndex === i 
                        ? 'border-[#FF6A3D] bg-[#FF6A3D]/5 shadow-lg shadow-[#FF6A3D]/5' 
                        : 'border-[#1F262F] bg-[#0E1116] hover:border-[#2D3643]'
                      }`}
                    >
                      <p className="text-sm text-[#EAEAF0] leading-relaxed italic font-medium">"{h}"</p>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#9AA3B2] uppercase tracking-widest mb-2">Writing Tone</label>
                <div className="grid grid-cols-3 gap-2">
                  {TONES.map(t => (
                    <button
                      key={t}
                      onClick={() => setTone(t as Tone)}
                      className={`px-3 py-2 rounded-lg text-xs font-bold transition-all ${
                        tone === t ? 'bg-[#FF6A3D] text-white shadow-lg shadow-[#FF6A3D]/20' : 'bg-[#1F262F] text-[#9AA3B2] hover:text-[#EAEAF0]'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          <div className="mt-8 flex items-center justify-between pt-4 border-t border-[#1F262F]">
            {step > 1 && (
              <button 
                onClick={() => setStep(s => s - 1)}
                className="text-[#9AA3B2] font-bold hover:text-[#EAEAF0] transition-colors uppercase text-xs tracking-widest"
              >
                Back
              </button>
            )}
            <button 
              onClick={handleNext}
              disabled={loading}
              className={`ml-auto flex items-center space-x-2 bg-[#FF6A3D] text-white px-8 py-3 rounded-xl font-black uppercase text-xs tracking-widest shadow-xl shadow-[#FF6A3D]/20 disabled:opacity-50 transition-all active:scale-95`}
            >
              {loading && (
                <svg className="animate-spin -ml-1 mr-3 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              )}
              <span>{loading ? 'Processing...' : step === 1 ? 'Analyze Topic' : 'Build Full Script'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
