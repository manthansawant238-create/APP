
import React from 'react';

interface PricingProps {
  currentTier: 'free' | 'creator' | 'agency';
  onSelectTier: (tier: 'free' | 'creator' | 'agency') => void;
}

export default function Pricing({ currentTier, onSelectTier }: PricingProps) {
  const tiers = [
    {
      id: 'free',
      name: 'Starter',
      price: '$0',
      description: 'Ideal for solo creators just starting out.',
      features: [
        '5 Scripts per month',
        'Standard AI Reasoning',
        'Basic Writing Frameworks',
        '1 Channel Profile',
        'Standard Export'
      ],
      buttonText: 'Current Plan',
      accent: 'text-[#9AA3B2]'
    },
    {
      id: 'creator',
      name: 'Creator',
      price: '$29',
      description: 'Scale your channel with viral logic.',
      features: [
        '50 Scripts per month',
        'Google Search Integration',
        'Advanced Frameworks',
        '5 Channel Profiles',
        'AI Section Regeneration',
        'Ember Hook Engine'
      ],
      buttonText: 'Upgrade to Creator',
      popular: true,
      accent: 'text-[#FF6A3D]'
    },
    {
      id: 'agency',
      name: 'Agency',
      price: '$99',
      description: 'The ultimate power tool for empires.',
      features: [
        'Unlimited Scripts',
        'Priority Pro Reasoning',
        '20+ Channel Profiles',
        'Team Management (Beta)',
        'Custom Frameworks',
        'VIP Support Access'
      ],
      buttonText: 'Go Agency Elite',
      accent: 'text-[#C77DFF]'
    }
  ];

  const comparisonFeatures = [
    { name: 'Monthly Scripts', free: '5', creator: '50', agency: 'Unlimited' },
    { name: 'AI Reasoning', free: 'Standard', creator: 'Advanced', agency: 'Priority Pro' },
    { name: 'Channel Profiles', free: '1', creator: '5', agency: '20+' },
    { name: 'Google Search Integration', free: false, creator: true, agency: true },
    { name: 'Section Regeneration', free: false, creator: true, agency: true },
    { name: 'Viral Hook Engine', free: 'Standard', creator: 'Ember Logic', agency: 'Ember Logic' },
    { name: 'Advanced Frameworks', free: false, creator: true, agency: true },
    { name: 'Support', free: 'Community', creator: 'Priority', agency: '24/7 VIP' },
  ];

  const CheckIcon = () => (
    <svg className="w-5 h-5 text-[#FF6A3D] mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
    </svg>
  );

  const CrossIcon = () => (
    <svg className="w-5 h-5 text-[#1F262F] mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
    </svg>
  );

  return (
    <div className="pb-20 animate-in fade-in slide-in-from-right-4 duration-500">
      <header className="text-center mb-16 pt-8">
        <h2 className="text-sm font-bold text-[#FF6A3D] uppercase tracking-[0.3em] mb-4">Upgrade Dashboard</h2>
        <h1 className="text-5xl font-extrabold text-[#EAEAF0] mb-6 tracking-tight">Fuel Your Growth Engine</h1>
        <p className="text-[#9AA3B2] max-w-2xl mx-auto text-lg leading-relaxed">
          Upgrade to unlock advanced viral structures, priority reasoning, and multi-channel management.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-24">
        {tiers.map((tier) => (
          <div 
            key={tier.id}
            className={`relative flex flex-col bg-[#151A22] border-2 rounded-[2.5rem] p-10 transition-all duration-300 hover:scale-[1.02] ${
              tier.id === currentTier 
                ? 'border-[#FF6A3D] ring-4 ring-[#FF6A3D]/5 shadow-2xl shadow-[#FF6A3D]/10' 
                : 'border-[#1F262F] hover:border-[#2D3643]'
            }`}
          >
            {tier.popular && (
              <div className="absolute -top-5 left-1/2 -translate-x-1/2 bg-[#FF6A3D] text-white text-[10px] font-black uppercase tracking-[0.2em] px-6 py-2 rounded-full shadow-lg shadow-[#FF6A3D]/30 border border-[#FF8A66]/30">
                Creator Choice
              </div>
            )}

            <div className="mb-8">
              <h3 className={`text-xl font-black uppercase tracking-tighter mb-2 ${tier.accent}`}>{tier.name}</h3>
              <div className="flex items-baseline space-x-1">
                <span className="text-4xl font-black text-[#EAEAF0]">{tier.price}</span>
                <span className="text-[#9AA3B2] font-medium">/mo</span>
              </div>
              <p className="text-[#9AA3B2] text-sm mt-4 leading-relaxed h-12">
                {tier.description}
              </p>
            </div>

            <div className="flex-1 space-y-4 mb-10">
              {tier.features.map((feature, i) => (
                <div key={i} className="flex items-center space-x-3 text-sm">
                  <div className={`flex-shrink-0 w-1.5 h-1.5 rounded-full ${tier.id === currentTier ? 'bg-[#FF6A3D]' : 'bg-[#2D3643]'}`} />
                  <span className="text-[#EAEAF0]/80 font-medium">{feature}</span>
                </div>
              ))}
            </div>

            <button 
              onClick={() => onSelectTier(tier.id as any)}
              disabled={tier.id === currentTier}
              className={`w-full py-4 rounded-2xl font-black text-sm uppercase tracking-widest transition-all ${
                tier.id === currentTier 
                  ? 'bg-[#1F262F] text-[#9AA3B2] cursor-default' 
                  : tier.popular 
                    ? 'bg-[#FF6A3D] text-white hover:bg-[#FF8A66] shadow-xl shadow-[#FF6A3D]/20 active:scale-95' 
                    : 'bg-[#1F262F] text-[#EAEAF0] hover:bg-[#2D3643] active:scale-95'
              }`}
            >
              {tier.id === currentTier ? 'Active Plan' : tier.buttonText}
            </button>
          </div>
        ))}
      </div>

      <div className="max-w-4xl mx-auto">
        <h3 className="text-2xl font-bold text-[#EAEAF0] mb-8 text-center">Feature Comparison</h3>
        <div className="bg-[#151A22] border border-[#1F262F] rounded-[2rem] overflow-hidden">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-[#1F262F]/50 border-b border-[#1F262F]">
                <th className="px-8 py-5 text-xs font-bold text-[#9AA3B2] uppercase tracking-widest">Feature</th>
                <th className="px-8 py-5 text-xs font-bold text-[#9AA3B2] uppercase tracking-widest text-center">Starter</th>
                <th className="px-8 py-5 text-xs font-bold text-[#FF6A3D] uppercase tracking-widest text-center">Creator</th>
                <th className="px-8 py-5 text-xs font-bold text-[#C77DFF] uppercase tracking-widest text-center">Agency</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F262F]">
              {comparisonFeatures.map((f, i) => (
                <tr key={i} className="hover:bg-[#1F262F]/20 transition-colors">
                  <td className="px-8 py-5 text-sm font-semibold text-[#EAEAF0]">{f.name}</td>
                  <td className="px-8 py-5 text-sm text-[#9AA3B2] text-center font-medium">
                    {typeof f.free === 'boolean' ? (f.free ? <CheckIcon /> : <CrossIcon />) : f.free}
                  </td>
                  <td className="px-8 py-5 text-sm text-[#EAEAF0] text-center font-bold">
                    {typeof f.creator === 'boolean' ? (f.creator ? <CheckIcon /> : <CrossIcon />) : f.creator}
                  </td>
                  <td className="px-8 py-5 text-sm text-[#C77DFF] text-center font-bold">
                    {typeof f.agency === 'boolean' ? (f.agency ? <CheckIcon /> : <CrossIcon />) : f.agency}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
